CREATE FUNCTION fun_amount_everyday(thisusername INT(6), thisday DATETIME)
  RETURNS DOUBLE(9, 2)
  BEGIN
declare amount double(9,2);
SELECT sum(case when typeid = 1 then billamount else 0-billamount end) into amount FROM tbbill 
where username=thisusername and date_format(billdate,'%Y-%m-%d') = thisday;
RETURN amount;
END;

