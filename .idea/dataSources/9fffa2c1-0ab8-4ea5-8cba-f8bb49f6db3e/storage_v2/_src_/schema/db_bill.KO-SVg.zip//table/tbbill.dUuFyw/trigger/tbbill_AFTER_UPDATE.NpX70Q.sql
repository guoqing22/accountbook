CREATE TRIGGER tbbill_AFTER_UPDATE
  AFTER UPDATE
  ON tbbill
  FOR EACH ROW
  BEGIN
declare temp double(9,2);
set temp = new.billamount - old.billamount;
if old.typeid = 1 then
update tbuser set useramount = useramount + temp where username = old.username;
elseif old.typeid = 0 then 
update tbuser set useramount = useramount - temp where username = old.username;
end if;
END;

