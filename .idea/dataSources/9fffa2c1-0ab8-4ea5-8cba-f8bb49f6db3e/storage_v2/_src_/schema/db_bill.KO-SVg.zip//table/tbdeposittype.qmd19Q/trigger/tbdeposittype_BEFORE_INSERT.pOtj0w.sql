CREATE TRIGGER tbdeposittype_BEFORE_INSERT
  BEFORE INSERT
  ON tbdeposittype
  FOR EACH ROW
  BEGIN
declare LAST_NUMBER INT(3);
declare NEXT_ID varchar(11);
SET LAST_NUMBER = (select right(depositid,3) from last_depositid);
IF LAST_NUMBER IS NULL THEN
SET LAST_NUMBER = 000;
END IF;
set NEXT_ID = (concat("depo",lpad(LAST_NUMBER+1,3,0)));
SET NEW.depositid := NEXT_ID;
END;

