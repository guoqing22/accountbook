CREATE TRIGGER tbbill_BEFORE_INSERT
  BEFORE INSERT
  ON tbbill
  FOR EACH ROW
  BEGIN
-- 判断收支备注是否是存在的，并且是否与收支相匹配,如果是支出，必须有一级标题 --
declare temp int default 0;
declare tempclassa int;
declare tempamount double(9,2);
if NEW.typeid = 0 then
	set tempclassa = (select count(*) from tbdrawtype where classa = NEW.classa);
	if tempclassa = 0 then
		SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = "classa data error";  
	else set temp = (select count(*) from tbdrawtype where classb = NEW.billinfo);
	end if;
elseif NEW.typeid = 1 then
	if new.classa is not null then
		SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = "classa should null";  
	else set temp = (select count(*) from tbdeposittype where typename = NEW.billinfo);
	end if;
end if;
if temp = 0 or temp is null then
	SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = "billinfo data error";  
end if;

-- 金额总数变化 --
if NEW.typeid = 0 then
         update tbuser set useramount = useramount - new.billamount where username = NEW.username;  
elseif NEW.typeid = 1 then
update tbuser set useramount = useramount + new.billamount where username = NEW.username;  
end if;
-- typeid取值约束 --
if NEW.typeid != "0" and new.typeid != "1" then
	SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = "typeid违反约束，0或1";  
end if;
-- 订单自动编号 --
set NEW.billid := (SELECT concat(date_format(now(),'%Y%m%d%H%i%S'),lpad(NEW.username * 7,7,0)));
-- 处理收支两种情况 --
END;

