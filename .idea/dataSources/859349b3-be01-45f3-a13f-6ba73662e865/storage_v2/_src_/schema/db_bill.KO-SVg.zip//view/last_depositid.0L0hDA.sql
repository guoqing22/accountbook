CREATE VIEW last_depositid AS
  (SELECT
     `db_bill`.`tbdeposittype`.`depositid` AS `depositid`,
     `db_bill`.`tbdeposittype`.`typename`  AS `typename`,
     `db_bill`.`tbdeposittype`.`mark`      AS `mark`
   FROM `db_bill`.`tbdeposittype`
   ORDER BY `db_bill`.`tbdeposittype`.`depositid` DESC
   LIMIT 1);

