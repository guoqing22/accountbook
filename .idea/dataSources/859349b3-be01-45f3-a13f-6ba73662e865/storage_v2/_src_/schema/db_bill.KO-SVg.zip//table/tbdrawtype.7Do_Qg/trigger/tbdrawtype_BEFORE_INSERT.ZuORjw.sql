CREATE TRIGGER tbdrawtype_BEFORE_INSERT
  BEFORE INSERT
  ON tbdrawtype
  FOR EACH ROW
  BEGIN
declare IDCODE varchar(20);
declare LAST_NUMBER INT(3);
declare NEXT_ID varchar(30);
SET IDCODE = (select drawclassbid(NEW.classa));
SET LAST_NUMBER = (select right(maxdrawid,3) from last_drawid where classa = NEW.classa);
if LAST_NUMBER IS NULL THEN 
SET LAST_NUMBER = 000;
END IF;
set NEXT_ID = (concat(IDCODE,lpad(LAST_NUMBER+1,3,0)));
SET NEW.drawid := NEXT_ID;
END;

