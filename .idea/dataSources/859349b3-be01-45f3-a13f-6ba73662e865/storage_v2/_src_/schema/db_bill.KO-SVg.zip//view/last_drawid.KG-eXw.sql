CREATE VIEW last_drawid AS
  (SELECT
     max(`db_bill`.`tbdrawtype`.`drawid`) AS `maxdrawid`,
     `db_bill`.`tbdrawtype`.`classa`      AS `classa`,
     `db_bill`.`tbdrawtype`.`classb`      AS `classb`,
     `db_bill`.`tbdrawtype`.`mark`        AS `mark`
   FROM `db_bill`.`tbdrawtype`
   GROUP BY `db_bill`.`tbdrawtype`.`classa`);

