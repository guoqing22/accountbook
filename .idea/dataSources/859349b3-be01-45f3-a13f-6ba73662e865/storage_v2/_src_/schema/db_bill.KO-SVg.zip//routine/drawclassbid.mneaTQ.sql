CREATE FUNCTION drawclassbid(classa VARCHAR(40))
  RETURNS VARCHAR(20)
  BEGIN
declare IDCODE varchar(20);
case classa
when "餐饮" then SET IDCODE = "caterers";
when "交通" then SET IDCODE = "traffic";
when "购物" then SET IDCODE = "shopping";
when "娱乐" then SET IDCODE = "entertainment";
when "医教" then SET IDCODE = "medicaleducation";
when "居家" then SET IDCODE = "dailylife";
when "投资" then SET IDCODE = "investment";
when "人情" then SET IDCODE = "world";
when "生意" then SET IDCODE = "business";
END CASE;
return IDCODE;
END;

